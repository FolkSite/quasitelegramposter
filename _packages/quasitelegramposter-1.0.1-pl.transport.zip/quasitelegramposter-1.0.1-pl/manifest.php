<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 quasi-art.ru

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '# quasiTelegramPoster
A MODX extra.',
    'changelog' => 'Changelog for quasiTelegramPoster.

quasiTelegramPoster 1.0.1 pl
==============
* Small refactoring.
* OnResourceAutoPublish now works.

quasiTelegramPoster 1.0.0 pl
==============
* Initial commit.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '58ea48f05c4eaf2e1501c7a8bea42963',
      'native_key' => 'quasitelegramposter',
      'filename' => 'modNamespace/5eb889660a10ab3f90d98dc19762daf0.vehicle',
      'namespace' => 'quasitelegramposter',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'd6586a4c177990d166f3fc4701ed857b',
      'native_key' => 33,
      'filename' => 'modPlugin/3dc6830a85fa6c424e7d54eaab2eaedd.vehicle',
      'namespace' => 'quasitelegramposter',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f65ddb72fa84edeaedf77f7b00e56c1e',
      'native_key' => 1,
      'filename' => 'modCategory/2a4c43092cde67cb6b1ec952f31a6934.vehicle',
      'namespace' => 'quasitelegramposter',
    ),
  ),
);